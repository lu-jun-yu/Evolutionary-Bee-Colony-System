import time
import pickle
import random
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from FunkSVD_Predict import get_weights
from AS import AS
from ACS import ACS
from E_BCS import EBCS

# 设置matplotlib绘图时的字体
plt.rcParams['font.sans-serif'] = ['SimHei']  # 对于Windows系统，使用SimHei字体以显示中文
plt.rcParams['axes.unicode_minus'] = False  # 设置以正常显示负号


# 定义路径推荐函数
def routes_rcmd(k, interests, driving_times, scenicSpot_times, num_ants, num_iterations,
        global_decay, local_decay, alpha, beta, q0, start, max_time, end, num_paths):
    # 记录程序开始时间
    start_time = time.time()
    Model = test_models[k]

    # 初始化蚁群系统并运行
    if Model == AS:
        model = Model(interests, driving_times, scenicSpot_times, num_ants, num_iterations, global_decay,
                      alpha, beta, q0, start, max_time, end, num_paths)
    elif Model == ACS:
        model = Model(interests, driving_times, scenicSpot_times, num_ants, num_iterations, global_decay, local_decay,
                      alpha, beta, q0, start, max_time, end, num_paths)
    else:
        model = Model(interests, driving_times, scenicSpot_times, num_ants, num_iterations, global_decay, local_decay, tail_decay,
                      alpha, beta, q0, start, max_time, end, num_paths)
    best_paths = model.run()

    model_interests[k].append(best_paths[0]['best_interest'])
    
    # print(best_paths)

    # 记录程序结束时间
    end_time = time.time()
    print(f'{Model.__name__}: {end_time - start_time}')
    return best_paths[0]['best_interest'],model.interest_history

# 1      2     3    4    5    6
# 0.3    1.3   3.0  4.6  6.2  7.7
# 0.001  1.47  3.3  5.3  7.3  9.1
# 0.001  1.47  3.4  5.4  7.3  9.2

# f(x=self.max_time/10) = 0.3 * x ** 2
# 0.3    1.2   2.7  4.8  7.5  10.8

test_models = [AS,ACS,EBCS]
result = {}
for i in [1,3,5,7,9]: # 2, 3, 4, 5, 6,
    try:
        with open('result.pkl', 'rb') as f:
            result = pickle.load(f)
    except:
        pass
    if (i in result) and result[i]:
        pass
    else:
        result[i] = {}    
    model_interests = []
    for k in range(len(test_models)):
        if (test_models[k].__name__ in result[i]) and result[i][test_models[k].__name__]:
            pass
        else:
            result[i][test_models[k].__name__] = {} 
        model_interests.append([])
        for j in range(0, 50):
            if (j in result[i][test_models[k].__name__]) and result[i][test_models[k].__name__][j]:
                continue 
            else:
                result[i][test_models[k].__name__][j] = {} 
            np.random.seed(j)  # 设置随机种子以复现结果
            random.seed(5)  # 设置随机种子以复现结果

            # 加载驾车时间数据
            with open("time_cost.pkl", 'rb') as f:
                driving_times = pickle.load(f)

            # 计算景点数量
            num_scenicSpots = len(driving_times)
            # 读取景点数据
            scenicSpots = pd.read_csv('../山西A级景区.csv',encoding='gbk')
            # 获取每个景点的游玩时间
            scenicSpot_times = scenicSpots['time'].to_numpy()

            # 定义景点类型和下标索引的映射
            type = {'地文景观类景区': 0, '水域风光类景区': 1, '生物景观类景区': 2, '天象与气候类景区': 3,
                    '历史遗址景区': 4, '现代建筑景区': 5, '博物馆景区': 6, '民族民俗景区': 7}
            level = {'3A': 750, '4A': 850, '5A': 950}

            # 根据用户ID获取景点权重
            num_users = len(pd.read_csv('users_weights.csv'))
            user_id = random.randint(0, num_users)
            weights = get_weights(user_id)

            # 计算景点的兴趣值
            interests = []
            for s in range(len(scenicSpots)):
                # 根据景点类型和等级计算权重
                interests.append(weights[type[scenicSpots['type'][s]]])
                interests[-1] *= level[scenicSpots['level'][s]]
            interests = np.array(interests) / sum(weights)

            # 设置蚂蚁数量、迭代次数等参数
            num_ants = 20
            num_iterations = 100
            global_decay = 0.1
            local_decay = 0.1
            tail_decay = 0.5
            alpha = 1
            beta = 2
            q0 = 0.9
            start = 8  # 起始景点
            end = None  # 结束景点（这里没有设置）
            max_time = 10 * i  # 最大旅行时间
            num_paths = 1

            # print(f"------------------{str(test_models[k])}------------------")
            temp1 ,temp2 = routes_rcmd(k, interests, driving_times, scenicSpot_times, num_ants, num_iterations,
                        global_decay, local_decay, alpha, beta, q0, start, max_time, end, num_paths)
            result[i][test_models[k].__name__][j]['best_interest'] = temp1
            result[i][test_models[k].__name__][j]['history_interest'] = temp2
            with open('result.pkl', 'wb') as f:
                pickle.dump(result, f)
            # print()

    # 可视化模型最佳兴趣值对比
    for k in range(len(model_interests)):
        plt.plot(np.array(model_interests[k]), label=f'{test_models[k].__name__}')
    plt.legend()
    plt.xlabel('随机种子')
    plt.ylabel('模型最佳兴趣值')
    plt.title('模型最佳兴趣值对比，天数' + str(i))
    plt.show()

    print(f"{i}天")
    for k in range(len(model_interests)):
        print(f"{test_models[k].__name__}推荐路径兴趣度均值：{np.mean(model_interests[k])}, 方差/游玩时间：{np.var(model_interests[k]) / (10 * i)}")
