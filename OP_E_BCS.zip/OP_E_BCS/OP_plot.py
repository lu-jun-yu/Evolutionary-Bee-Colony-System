import time
import pickle
import random
import numpy as np

import matplotlib.pyplot as plt
# 设置全局字体为新罗马字体
plt.rcParams['font.family'] = 'serif'
plt.rcParams['font.serif'] = ['Times New Roman'] + plt.rcParams['font.serif']


with open('all_result.pkl', 'rb') as f:
    all_result = pickle.load(f)
    
#%% PLOT
plot_data = [] # 用于绘制折线图：date-algorithm_name-history_interest
models = ["AS","ACS","EBCS"]
for index in range(1,11):
    date = all_result[index]
    plot_data.append({})
    for model in models:
        id_best = 0
        best_interest = 0
        for seed in range(50):
            if best_interest < date[model][seed]['best_interest']:
                id_best = seed
                best_interest = date[model][seed]['best_interest']
        plot_data[index-1][model] = date[model][id_best]['history_interest']

# for index in range(10):
    