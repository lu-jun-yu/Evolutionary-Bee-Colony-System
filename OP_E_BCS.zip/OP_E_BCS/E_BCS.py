import numpy as np
import random
import time
import copy
from GdA import GdA
from bisect import insort
from collections import deque
from collections import OrderedDict

#%%
class EBCS:

    ### start      #####################################
    class individual:

        def __init__(self, alpha, beta, q0):
            self.alpha = {'explorer': alpha, 'developer': alpha}
            self.beta = {'explorer': beta, 'developer': beta}
            self.q0 = {'explorer': q0, 'developer': q0}
            
            self.v = [{'explorer': random.uniform(-0.1, 2), 'developer': random.uniform(-1, 1)},{'explorer': random.uniform(-1, 1), 'developer': random.uniform(-1, 1)},{'explorer': random.uniform(-1, 1), 'developer': random.uniform(-1, 1)}]  #粒子移动速度
            self.historic_best_parameter = [self.alpha , self.beta , self.q0]
            self.historic_best_fitness = -np.inf
    ### end        #####################################

    # 类的初始化函数
    def __init__(self, interests, driving_times, scenicSpot_times, num_ants, num_iterations, global_decay, local_decay,
                 tail_decay, alpha, beta, q0, start, max_time, end=None, num_paths=3):
        self.interests = interests  # 景点的兴趣值
        self.times = driving_times + scenicSpot_times  # 景点间驾车时间
        self.scenicSpots_times = scenicSpot_times  # 在每个景点的游玩时间
        self.num_ants = num_ants  # 蚂蚁的数量
        self.num_iterations = num_iterations  # 迭代次数

        self.global_decay = 0.5
        self.local_decay = 0.5  # 信息素的衰减系数
        self.tail_decay = 0.5
        self.down_bound = 0.4
        self.alpha = alpha  # 信息素重要程度的参数
        self.beta = beta    # 兴趣值重要程度的参数
        self.q0 = q0        # 探索因子，用于控制探索的概率

        ### start：     #####################################
        self.ant_individual = [self.individual(random.uniform(0.1, 2), random.uniform(1, 5), random.uniform(0.1, 0.9))
                               for _ in range(self.num_ants)]
        
        # self.ant_individual = [self.individual(self.alpha, self.beta, self.q0)
        #                        for _ in range(self.num_ants)]
        ### end        #####################################

        self.start = start  # 起始景点
        self.end = end  # 结束景点（可选）
        self.max_time = max_time  # 允许的最大旅行时间
        self.max_run_time = 0.2 * (self.max_time / 10) ** 2  # 允许的最大运行时间
        self.num_scenicSpots = len(interests)  # 景点的数量

        self.initial = GdA(interests, driving_times, scenicSpot_times, num_ants, num_iterations, global_decay, local_decay, tail_decay,
                        alpha, beta, q0, start, max_time, end, 1).run()
        self.best_local_paths = [self.initial[0]]
        # print(self.initial)

        self.attraction_enhancement = 0
        self.repulsion_enhancement = 0
        self.attractive_force_field = np.ones((self.num_scenicSpots, self.num_scenicSpots))
        self.repulsive_force_field = np.ones((self.num_scenicSpots, self.num_scenicSpots))

        self.best_paths = [self.initial[0]]
        self.best_paths.extend([{'best_interest': -np.inf, 'best_path': []} for _ in range(num_paths - 1)])  # 最佳路径
        self.interest_history = []  # 记录每次迭代的最佳兴趣值，用于后续的可视化
        self.pheromones = np.ones((self.num_scenicSpots, self.num_scenicSpots)) * 10 # (intial[0]["best_interest"] / self.max_time)  # 初始化信息素矩阵，初始值设为1

    # 定义蚁群系统的运行函数
    def run(self):
        global end
        start = time.time()
        all_paths = set()  # 存储所有经过的路径
        ant = {'explorer': 0, 'developer': 0}
        paths = {'explorer': [], 'developer': []}  # 存储所有蚂蚁的路径
        path_interests = {'explorer': [], 'developer': []}  # 存储所有路径的兴趣值总和

        # 开始迭代
        for iteration in range(self.num_iterations):

            # 探索阶段
            self.repulsion_enhancement = 0
            result = self.search('explorer', start, all_paths, ant, paths, path_interests, iteration)
            if result is not None:
                return result

            # 记录时间
            end = time.time()
            # 设置早停
            if end - start > self.max_run_time:
                break

            # 开发阶段
            self.attraction_enhancement = 0
            result = self.search('developer', start, all_paths, ant, paths, path_interests, iteration)
            if result is not None:
                return result

            # 记录时间
            end = time.time()
            #设置早停
            if end - start > self.max_run_time:
                break
        # print(iteration)
        # 返回最佳路径和兴趣值
        return self.best_paths

    # 搜索函数
    def search(self, mode, start, all_paths, ant, paths, path_interests, iteration):
        ant_count = 0
        LS_ant_count = 0
        while True:
            while ant[mode] < self.num_ants:
                if mode == 'explorer':
                    self.repulsion_enhancement = 1.1
                #     self.repulsion_enhancement += 1
                #     self.repulsive_force_field_update(explorer)

                time_used = self.scenicSpots_times[self.start]
                path = [self.start]  # 初始化当前蚂蚁的路径
                if tuple(path) in all_paths:
                    return self.best_paths
                path_interest = self.find_new_path(path, all_paths, self.interests[self.start],
                                                   time_used, ant[mode], mode)

                # 如果完成了一条完整的路径，则记录该路径及其兴趣值
                paths[mode].append(path)
                if self.max_time <= 10 * 8:
                    all_paths.add(tuple(path))
                if self.end is None or path[-1] == self.end:
                    path_interests[mode].append(path_interest)
                else:
                    path_interests[mode].append(0)

                # 更新全局最佳路径和兴趣值
                new_path = {'best_interest': path_interests[mode][-1], 'best_path': paths[mode][-1]}
                # insort(self.best_paths, new_path, key=lambda p: -p['best_interest'])
                
                self.best_paths.sort(key=lambda p: -p['best_interest'])

                # 然后，找到新路径应该插入的位置
                insert_index = 0
                for i, path in enumerate(self.best_paths):
                    if new_path['best_interest'] < path['best_interest']:
                        insert_index = i + 1
                        break

                # 最后，插入新路径到找到的位置
                self.best_paths.insert(insert_index, new_path)
                
                self.best_paths.pop()

                # 记录这次最佳兴趣值，用于后续可视化
                self.interest_history.append(self.best_paths[0]['best_interest'])

                ant_count += 1

                # 记录时间
                end = time.time()
                # 设置早停
                if end - start > self.max_run_time:
                    return None

                if mode == 'explorer':
                    if path_interests[mode][-1] > self.best_local_paths[0]['best_interest']:
                        tmp_path = {'best_interest': path_interests[mode][-1], 'best_path': paths[mode][-1]}
                        # print(tmp_path)
                        self.best_local_paths.append(tmp_path)
                        return None
                if mode == 'developer':
                    interest_growth = path_interests[mode][-1] - self.best_local_paths[-1]['best_interest']
                    if interest_growth > 0:
                        self.attraction_enhancement += interest_growth * self.max_time / 10 / \
                                                       self.best_local_paths[-1]['best_interest']
                        tmp_path = {'best_interest': path_interests[mode][-1], 'best_path': paths[mode][-1]}
                        self.best_local_paths[-1] = tmp_path
                        self.attractive_force_field_update(ant[mode])
                        LS_ant_count += ant_count
                        ant_count = 0

                ant[mode] += 1

                # 更新信息素
                if ant['explorer'] + ant['developer'] == self.num_ants:
                    index = iteration * 2
                    self.global_decay = (1 - 2 * self.down_bound) / (1 + np.e ** (-index)) + self.down_bound
                    self.local_decay = 1 - self.global_decay
                    self.tail_decay = 1 - self.global_decay
                    self.global_pheromones_update()

                if mode == 'developer' and ant_count == 30:
                    return None
                if mode == 'explorer' and ant_count == self.max_time + 10:
                    self.best_local_paths.append(self.best_paths[0])
                    return None
            else:
                # 蚂蚁进化
                # self.ga(mode, path_interests[mode], iteration)
                self.pso(mode,path_interests,iteration)
                # self.de(mode,path_interests[mode],iteration)
                # self.gp(mode,path_interests[mode],iteration)
                paths[mode] = []  # 存储所有蚂蚁的路径
                path_interests[mode] = []  # 存储所有路径的兴趣值总和
                ant[mode] = 0

    # 概率性探索函数
    def find_new_path(self, path, all_paths, path_interest, time_used, ant, mode):
        probabilities = []  # 存储转移到每个景点的概率
        spend_times = []  # 存储到达每个景点所需的时间

        # 计算到每个景点的概率
        for next_scenicSpot in range(self.num_scenicSpots):
            # 计算到下一个景点将要花费的时间
            spend_time = self.times[path[-1]][next_scenicSpot]
            spend_times.append(spend_time)
            # 如果下一个景点不在当前路径中，并且时间允许，则计算概率
            if next_scenicSpot not in path and spend_time < self.max_time - time_used:
                if self.max_time <= 10 * 8 and (*path, next_scenicSpot) in all_paths:
                    # if tuple(path + [next_scenicSpot]) in all_paths:
                    probabilities.append(0)
                    continue
                # 计算景点的信息素和兴趣值的组合影响力
                if mode == 'developer':
                    force = self.attractive_force_field[path[-1]][next_scenicSpot]
                else:
                    force = self.repulsive_force_field[path[-1]][next_scenicSpot]
                tau_eta = (self.pheromones[path[-1]][next_scenicSpot] **
                           self.ant_individual[ant].alpha[mode]) * \
                          ((self.interests[next_scenicSpot] / spend_time) **
                           self.ant_individual[ant].beta[mode]) * force
                probabilities.append(tau_eta)
            else:
                probabilities.append(0)  # 如果景点不可达或已经访问过，则概率为0

        sum_probabilities = sum(probabilities)
        if sum_probabilities == 0:
            return path_interest

        # 归一化概率
        probabilities = np.array(probabilities)
        probabilities /= sum_probabilities

        # 根据探索因子q0决定是贪婪选择还是随机选择下一个景点
        if np.random.rand() < self.ant_individual[ant].q0[mode]:
            # 开发：选择概率最高的景点
            next_scenicSpot = np.argmax(probabilities)
        else:
            # 探索：根据概率分布随机选择景点
            next_scenicSpot = np.random.choice(range(self.num_scenicSpots), p=probabilities)

        path.append(next_scenicSpot)
        path_interest += self.interests[next_scenicSpot]
        time_used += spend_times[next_scenicSpot]

        # 执行局部信息素更新
        self.local_pheromone_update(path[-2], next_scenicSpot, spend_times)

        if self.max_time - time_used <= np.log(0.14 * self.max_time ** 2) and \
                path_interest / time_used > self.best_local_paths[-1]['best_interest'] / self.max_time:
            # 寻找下一个景点
            return self.find_optimal_path(path, all_paths, path_interest, time_used)
        else:
            # 寻找下一个景点
            return self.find_new_path(path, all_paths, path_interest, time_used, ant, mode)

    # 确定性开发函数
    def find_optimal_path(self, path, all_paths, path_interest, time_used):
        optimal_path = {'best_interest': -np.inf, 'best_tail_path': [], 'time_used': time_used}
        remain_scenicSpot = np.setdiff1d(np.arange(self.num_scenicSpots), np.array(path))
        ori_path_len = len(path)
        path_tuple = tuple(path)

        # 执行广度优先搜索实现分枝定界
        tail_start = tuple(path[-1:])
        queue = deque([(tail_start, path_interest, time_used)])
        tail_time = {frozenset(tail_start): time_used}
        while queue:
            current_tail, current_interest, current_time = queue.popleft()
            finish = 1

            for next_scenicSpot in remain_scenicSpot:
                spend_time = self.times[current_tail[-1]][next_scenicSpot]
                new_time = current_time + spend_time
                if next_scenicSpot not in frozenset(current_tail) and new_time < self.max_time:
                    new_tail = current_tail + (next_scenicSpot,)
                    if path_tuple + new_tail[1:] not in all_paths:
                        finish = 0
                        new_tail_set = frozenset(new_tail)
                        if new_tail_set in tail_time and tail_time[new_tail_set] <= new_time:
                            continue
                        tail_time[new_tail_set] = new_time
                        new_interest = current_interest + self.interests[next_scenicSpot]
                        queue.append((new_tail, new_interest, new_time))

            if finish == 1 and current_interest > optimal_path['best_interest']:
                optimal_path['best_interest'] = current_interest
                optimal_path['best_tail_path'] = current_tail[1:]
                optimal_path['time_used'] = current_time

        tail_path = copy.deepcopy(optimal_path['best_tail_path'])
        path.extend(tail_path)

        # 执行尾部信息素更新
        self.tail_pheromone_update(path[ori_path_len - 1:], optimal_path['best_interest'] - path_interest,
                                   optimal_path['time_used'] - time_used)

        # 寻找下一个景点
        return optimal_path['best_interest']

    # 引力场更新函数
    def attractive_force_field_update(self, ant):
        self.attractive_force_field /= self.attractive_force_field
        self.attractive_force_field[:, self.best_local_paths[-1]['best_path']] = 1 + self.attraction_enhancement

        # for i in range(self.num_ants):
        #     self.ant_individual[i].alpha['developer'] = self.ant_individual[ant].alpha['developer']
        #     self.ant_individual[i].beta['developer'] = self.ant_individual[ant].beta['developer']
        #     self.ant_individual[i].q0['developer'] = self.ant_individual[ant].q0['developer']

    # 斥力场更新函数
    def repulsive_force_field_update(self, ant):
        self.repulsive_force_field /= self.repulsive_force_field
        for i in range(len(self.best_local_paths)):
            for j in range(len(self.best_local_paths[i]['best_path'])):
                self.repulsive_force_field[self.best_local_paths[i]['best_path'][j]] = \
                    1 / self.repulsion_enhancement

    # 定义全局信息素更新函数
    def global_pheromones_update(self):
        # 应用信息素衰减
        self.pheromones *= (1 - self.global_decay)

        # 遍历最优路径中的每段旅程
        for i in range(len(self.best_paths)):
            for j in range(len(self.best_paths[i]['best_path']) - 1):
                # 增加新的信息素
                self.pheromones[self.best_paths[i]['best_path'][j]][self.best_paths[i]['best_path'][j + 1]] += \
                    self.global_decay * (self.best_paths[i]['best_interest'] / self.max_time)

    # 定义局部信息素更新函数
    def local_pheromone_update(self, current_scenicSpot, next_scenicSpot, spend_times):
        # 局部更新规则
        self.pheromones[current_scenicSpot][next_scenicSpot] *= (1 - self.local_decay)
        self.pheromones[current_scenicSpot][next_scenicSpot] += self.local_decay * (
                self.interests[next_scenicSpot] / spend_times[next_scenicSpot])

    # 定义尾部信息素更新函数
    def tail_pheromone_update(self, tail_path, tail_interest, tail_time):
        # 遍历路径中的每段旅程
        for j in range(len(tail_path) - 1):
            self.pheromones[tail_path[j]][tail_path[j + 1]] *= (1 - self.tail_decay)
            # 增加新的信息素
            self.pheromones[tail_path[j]][tail_path[j + 1]] += \
                self.tail_decay * (tail_interest / tail_time)

    # 定义个体进化遗传算法
    def ga(self, mode, path_interests, iteration):
        sorted_indices = sorted(range(self.num_ants), key=lambda k: path_interests[k], reverse=True)
        selected_indices = sorted_indices[:self.num_ants // 2]
        selected_indices.extend(selected_indices)
        random.shuffle(selected_indices)

        new_population = []
        mutation_rate = 0.0025 * self.max_time / (iteration + 1) + 0.1  # 变异率
        # mutation_rate = 1-iteration*0.009
        # mutation_rate = 1

        # 交叉
        for _ in range(len(selected_indices) // 2):
            parent1 = self.ant_individual[selected_indices.pop()]
            parent2 = self.ant_individual[selected_indices.pop()]
            if random.random() < mutation_rate:
                random_number = random.choice([1, 2, 3])
                # 分支根据随机选择执行
                if random_number == 1:
                    tmp = parent1.alpha[mode]
                    parent1.alpha[mode] = parent2.alpha[mode]
                    parent2.alpha[mode] = tmp
                elif random_number == 2:
                    tmp = parent1.beta[mode]
                    parent1.beta[mode] = parent2.beta[mode]
                    parent2.beta[mode] = tmp
                else:
                    tmp = parent1.q0[mode]
                    parent1.q0[mode] = parent2.q0[mode]
                    parent2.q0[mode] = tmp
            else:
                pass
            new_population.append(parent1)
            new_population.append(parent2)

        ## 变异
        for index in range(self.num_ants):
            if random.random() < mutation_rate:
                new_population[index].alpha[mode] = random.uniform(0.1, 2.0)
                new_population[index].beta[mode] = random.uniform(2.0, 10.0)
                new_population[index].q0[mode] = random.uniform(0.1, 0.3)
            else:
                pass
        for i in sorted_indices[:round(self.num_ants * 0.1)]:  # 精英策略
            new_population[i].alpha[mode] = self.ant_individual[i].alpha[mode]
            new_population[i].beta[mode] = self.ant_individual[i].beta[mode]
            new_population[i].q0[mode] = self.ant_individual[i].q0[mode]

        self.ant_individual = new_population
        
    def pso(self,mode, path_interests,iteration):
        # 一种改进粒子群算法
        # 找到最好的一个粒子，和次好的两个粒子，次好的两个粒子向最好的一个粒子移动；其余粒子向离这三个粒子中最近的一个粒子移动。
        # 参数边界处理：截断并反弹
        # 速度：考虑惯性、个体历史最佳位置，全局历史最佳位置
        # 全局最优个体参数不变
        def short(mode,best_individual,second_individual,third_individual,me):
            d =[0,0,0]
            d[0] = (best_individual.alpha[mode]-me.alpha[mode])**2+ \
                (best_individual.beta[mode]-me.beta[mode])**2+(best_individual.q0[mode]-me.q0[mode])**2
            d[1] = (second_individual.alpha[mode]-me.alpha[mode])**2+ \
                (second_individual.beta[mode]-me.beta[mode])**2+(second_individual.q0[mode]-me.q0[mode])**2
            d[2] = (third_individual.alpha[mode]-me.alpha[mode])**2+ \
                (third_individual.beta[mode]-me.beta[mode])**2+(third_individual.q0[mode]-me.q0[mode])**2
            return d.index(max(d))
        def check(mode,me,local_mode):
            if local_mode == 0:
            # 边界限制与速度反向（反弹）：
                k = 0.5
                if me.alpha[mode] < 0.1:
                    me.alpha[mode] = 0.1
                    me.v[0][mode] = -me.v[0][mode] *k
                elif me.alpha[mode] > 2.0:
                    me.alpha[mode] = 2.0
                    me.v[0][mode] = -me.v[0][mode] *k

                if me.beta[mode] < 2.0:
                    me.beta[mode] = 2.0
                    me.v[1][mode] = -me.v[1][mode] *k
                elif me.beta[mode] > 10.0:
                    me.beta[mode] = 10.0
                    me.v[1][mode] = -me.v[1][mode] *k
                
                if me.q0[mode] < 0.1:
                    me.q0[mode] = 0.1
                    me.v[2][mode] = -me.v[2][mode] *k
                elif me.q0[mode] > 0.3:
                    me.q0[mode] = 0.3
                    me.v[2][mode] = -me.v[2][mode] *k
            
            if local_mode == 1:
                # 速度限制：
                while abs(me.v[0][mode]) > 0.85:
                    me.v[0][mode] = me.v[0][mode]  / abs(me.v[0][mode]) * 0.85
                while abs(me.v[1][mode]) > 4.0:
                    me.v[1][mode] = me.v[1][mode] / abs(me.v[1][mode]) * 4.0
                while abs(me.v[2][mode]) > 0.1:
                    me.v[2][mode] = me.v[2][mode] / abs(me.v[2][mode]) * 0.1
        
        for index, individual in enumerate(self.ant_individual):
            if individual.historic_best_fitness < path_interests[mode][index]:
                individual.historic_best_fitness = path_interests[mode][index]
                individual.historic_best_parameter[0] =individual.alpha[mode]
                individual.historic_best_parameter[1] =individual.beta[mode]
                individual.historic_best_parameter[2] =individual.q0[mode]
        sorted_indices = sorted(range(self.num_ants//2), key=lambda k: path_interests[mode][k], reverse=True)
        best_individual = self.ant_individual[sorted_indices[0]]
        second_individual = self.ant_individual[sorted_indices[1]]
        third_individual = self.ant_individual[sorted_indices[2]]
        best3_individual = [best_individual,second_individual,third_individual]
        
        # best_individual.v = [0,0,0]
        best_individual.v = [{'explorer': 0, 'developer': 0},{'explorer': 0, 'developer':0},{'explorer': 0, 'developer': 0}]  #粒子移动速度
        # omega = 0.5
        # c2 = 2   # 群体经验项学习因子
        # c1 = 1
        omega =  0.5  - (0.5 * iteration) / (self.num_iterations) # 非线性递减惯性权重
        # omega = 0.5
        c2 = 2 + iteration /self.num_iterations   # 群体经验项学习因子
        c1 = 1 - iteration /self.num_iterations 
        # omega = 0.1 / (iteration + 1) + 0  # 非线性递减惯性权重
        # # omega = 0.5
        # c1 = 0.4 + 0.01 * iteration   # 群体经验项学习因子
        # c2 = 0.1   
        
        # omega = 0.1 / (iteration + 1) + 0  # 非线性递减惯性权重
        # # omega = 0.5
        # c1 = 0.2 + 0.01 * iteration   # 群体经验项学习因子
        # c2 = 0.1   # 个体经验项学习因子
        
        # omega = 0.5 - iteration / 2 / self.num_iterations   # 非线性递减惯性权重
        # c1 = 0.5 * iteration / self.num_iterations + 0.5    # 群体经验项学习因子
        # c2 = 1   # 个体经验项学习因子
        
        for index,i in enumerate(self.ant_individual):
            
            # if index ==self.num_ants:
            #     break
            if i == best_individual:
                continue
            k = short(mode,best_individual,second_individual,third_individual,i)
            if i ==second_individual or i == third_individual:
                k = 0
            i.v[0][mode] = c2 * random.random() * (best3_individual[k].alpha[mode] - i.alpha[mode]) + \
                     c1 * random.random() * (i.historic_best_parameter[0]-i.alpha[mode]) + omega * i.v[0][mode]
            
            i.v[1][mode] = c2 * random.random()*(best3_individual[k].beta[mode] - i.beta[mode]) + \
                     c1 * random.random()*(i.historic_best_parameter[1]-i.beta[mode]) + omega * i.v[1][mode]
            i.v[2][mode] = c2 * random.random()*(best3_individual[k].q0[mode] - i.q0[mode]) + \
                     c1 * random.random()*(i.historic_best_parameter[2]-i.q0[mode]) + omega * i.v[2][mode]
            # print('《《')
            # print(i.v)
            # print(str(i.alpha)+','+str(i.beta)+','+str(i.q0))
            # print('》》')
            check(mode,i,1)
            i.alpha[mode] += i.v[0][mode]
            i.beta[mode] += i.v[1][mode]
            i.q0[mode] += i.v[2][mode]
            # print(i.v)
            check(mode,i,0)
    