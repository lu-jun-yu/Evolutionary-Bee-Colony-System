# 导入所需的库
import numpy as np
import time
from bisect import insort


# 定义蚁群系统算法类
class AS:
    # 类的初始化函数
    def __init__(self, interests, driving_times, scenicSpot_times, num_ants, num_iterations, decay, alpha, beta, q0, start, max_time, end=None, num_paths=3):
        self.interests = interests  # 景点的兴趣值
        self.driving_times = driving_times          # 景点间驾车时间
        self.scenicSpots_times = scenicSpot_times   # 在每个景点的游玩时间
        self.num_ants = num_ants    # 蚂蚁的数量
        self.num_iterations = num_iterations  # 迭代次数

        self.decay = decay          # 信息素的衰减系数
        self.alpha = alpha          # 信息素重要程度的参数
        self.beta = beta            # 兴趣值重要程度的参数
        self.q0 = q0                # 探索因子，用于控制探索的概率

        self.start = start          # 起始景点
        self.end = end              # 结束景点（可选）
        self.max_time = max_time    # 允许的最大旅行时间
        self.max_run_time = 0.2 * (self.max_time / 10) ** 2   # 允许的最大运行时间
        self.num_scenicSpots = len(interests)  # 景点的数量
        self.pheromones = np.ones((self.num_scenicSpots, self.num_scenicSpots)) * 10  # 初始化信息素矩阵，初始值设为1
        self.best_paths = [{'best_interest': -np.inf, 'best_path': []} for _ in range(num_paths)] # 最佳路径
        self.interest_history = []  # 记录每次迭代的最佳兴趣值，用于后续的可视化

    # 定义蚁群系统的运行函数
    def run(self):
        global end
        start = time.time()
        all_paths = set()  # 存储所有经过的路径

        # 开始迭代
        for iteration in range(self.num_iterations):
            paths = []  # 存储所有蚂蚁的路径
            path_interests = []  # 存储所有路径的兴趣值总和

            # 遍历所有的蚂蚁
            for ant in range(self.num_ants):
                time_used = self.scenicSpots_times[self.start]  # 初始化已使用的时间为起始景点的游玩时间
                current_scenicSpot = self.start  # 设置当前的景点为起始景点
                path = [current_scenicSpot]  # 初始化当前蚂蚁的路径
                path_interest = self.interests[current_scenicSpot]  # 初始化当前路径的兴趣值总和

                # 循环，直至时间耗尽或者完成旅行
                while time_used < self.max_time:
                    # 选择下一个景点
                    next_scenicSpot, spend_times = self.select_next_scenicSpot(current_scenicSpot, path, time_used)
                    if next_scenicSpot is None:  # 如果没有下一个景点可去，则结束循环
                        break
                    # 更新路径和时间
                    path.append(next_scenicSpot)
                    time_used += spend_times[next_scenicSpot]
                    # 更新兴趣值
                    path_interest += self.interests[next_scenicSpot]
                    # 更新当前景点
                    current_scenicSpot = next_scenicSpot
                    # 如果设置了结束景点，并且已到达，则结束循环
                    if self.end is not None and current_scenicSpot == self.end:
                        break

                # 如果完成了一条完整的路径，则记录该路径及其兴趣值
                paths.append(path)
                if self.end is None or path[-1] == self.end:
                    path_interests.append(path_interest)
                else:
                    path_interests.append(0)

                # 更新全局最佳路径和兴趣值
                new_path = {'best_interest': path_interests[-1], 'best_path': paths[-1]}
                # insort(self.best_paths, new_path, key=lambda p: -p['best_interest'])
                if self.best_paths[0]['best_interest'] < new_path['best_interest']:
                    self.best_paths[0] = new_path
                all_paths.add(tuple(path))

                # 记录这次迭代的最佳兴趣值，用于后续可视化
                self.interest_history.append(self.best_paths[0]['best_interest'])

                # 记录时间
                end = time.time()
                # 设置早停
                if end - start > self.max_run_time:
                    break

            # 设置早停
            if end - start > self.max_run_time:
                break

            # 更新信息素
            self.update_pheromones(paths, path_interests)

        # 返回最佳路径和兴趣值
        return self.best_paths

    # 定义选择下一个景点的函数
    def select_next_scenicSpot(self, current_scenicSpot, path, time_used):
        probabilities = []  # 存储转移到每个景点的概率
        spend_times = []  # 存储到达每个景点所需的时间
        # 计算到每个景点的概率
        for next_scenicSpot in range(self.num_scenicSpots):
            # 计算到下一个景点所需的时间
            spend_time = self.driving_times[current_scenicSpot][next_scenicSpot] + self.scenicSpots_times[next_scenicSpot]
            spend_times.append(spend_time)
            # 如果下一个景点不在当前路径中，并且时间允许，则计算概率
            if next_scenicSpot not in path and spend_time < self.max_time - time_used:
                # 计算景点的信息素和兴趣值的组合影响力
                tau_eta = (self.pheromones[current_scenicSpot][next_scenicSpot] ** self.alpha) * ((self.interests[next_scenicSpot] / spend_time) ** self.beta)
                probabilities.append(tau_eta)
            else:
                probabilities.append(0)  # 如果景点不可达或已经访问过，则概率为0

        sum_probabilities = sum(probabilities)
        if sum_probabilities == 0:
            return None, spend_times  # 如果没有可去的景点，则返回None

        # 归一化概率
        probabilities = np.array(probabilities)
        probabilities /= sum_probabilities
        next_scenicSpot = np.random.choice(range(self.num_scenicSpots), p=probabilities)
        return next_scenicSpot, spend_times

    # 定义更新信息素的函数
    def update_pheromones(self, paths, path_interests):
        # 应用信息素衰减
        self.pheromones *= (1 - self.decay)

        # 遍历蚂蚁访问过的所有路径
        for path, path_interest in zip(paths, path_interests):
            # 遍历路径中的每段旅程
            for i in range(len(path) - 1):
                # 增加新的信息素
                self.pheromones[path[i]][path[i + 1]] += path_interest / self.max_time
