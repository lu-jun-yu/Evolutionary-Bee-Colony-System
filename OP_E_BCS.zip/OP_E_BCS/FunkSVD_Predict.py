# 导入所需库
import numpy as np
import pandas as pd
import pickle


# 定义获取权重的函数
def get_weights(user_id):
    # 该函数用于预测新用户对于不同类型景区的权重，这些权重可能在用户数据中未提供

    # 读取存储用户权重的CSV文件，并将其转换为numpy数组
    data = pd.read_csv('users_weights.csv').to_numpy()

    # 打开之前训练并保存的SVD模型，用于预测权重
    with open('SVDfillWeightsModel.pickle', 'rb') as file:
        # 使用pickle加载模型
        SVDFillWeightsModel = pickle.load(file)

    # 初始化一个列表，用于存储填充后的权重
    weights_filled = []

    # 遍历所有景点的权重
    for item_id in range(8):
        # 如果用户对某个景点的权重是未知的，则使用模型进行预测
        if np.isnan(data[user_id][item_id]):
            # 使用SVD模型预测用户对景点的权重
            prediction = SVDFillWeightsModel.predict(user_id, item_id)
            # 将预测结果四舍五入后添加到权重列表中
            weights_filled.append(round(prediction.est))
        else:
            # 如果用户已提供权重，则直接添加到权重列表中
            weights_filled.append(data[user_id][item_id])

    # 返回填充后的用户权重列表
    return weights_filled
