# 导入所需的库
import numpy as np

# 定义蚁群系统算法类
class GdA:

    # 类的初始化函数
    def __init__(self, interests, driving_times, scenicSpot_times, num_ants, num_iterations, global_decay, local_decay,
                 tail_decay,
                 alpha, beta, q0, start, max_time, end=None, num_paths=3):
        self.interests = interests  # 景点的兴趣值
        self.driving_times = driving_times  # 景点间驾车时间
        self.scenicSpots_times = scenicSpot_times  # 在每个景点的游玩时间
        self.num_ants = 1  # 蚂蚁的数量
        self.num_iterations = 1  # 迭代次数

        self.start = start  # 起始景点
        self.end = end  # 结束景点（可选）
        self.max_time = max_time  # 允许的最大旅行时间
        self.num_scenicSpots = len(interests)  # 景点的数量
        self.pheromones = np.ones((self.num_scenicSpots, self.num_scenicSpots)) * 10  # 初始化信息素矩阵，初始值设为1
        self.best_paths = [{'best_interest': -np.inf, 'best_path': []} for _ in range(num_paths)]  # 最佳路径
        self.interest_history = []  # 记录每次迭代的最佳兴趣值，用于后续的可视化

    # 定义蚁群系统的运行函数
    def run(self):
        all_paths = set()  # 存储所有经过的路径

        # 开始迭代
        for iteration in range(self.num_iterations):
            paths = []  # 存储所有蚂蚁的路径
            path_interests = []  # 存储所有路径的兴趣值总和

            # 遍历所有的蚂蚁
            for ant in range(self.num_ants):
                time_used = self.scenicSpots_times[self.start]
                path = [self.start]  # 初始化当前蚂蚁的路径
                if tuple(path) in all_paths:
                    return self.best_paths
                path_interest = self.find_new_path(path, all_paths, self.interests[self.start], time_used, ant)

                # 如果完成了一条完整的路径，则记录该路径及其兴趣值
                paths.append(path)
                if self.max_time <= 10 * 8:
                    all_paths.add(tuple(path))
                if self.end is None or path[-1] == self.end:
                    path_interests.append(path_interest)
                else:
                    path_interests.append(0)

                # 更新全局最佳路径和兴趣值
                for i in range(len(self.best_paths)):
                    if path_interests[-1] > self.best_paths[i]['best_interest']:
                        tmp_path = {'best_interest': path_interests[-1], 'best_path': paths[-1]}
                        self.best_paths.insert(i, tmp_path)
                        self.best_paths.pop()
                        break

            # 记录这次迭代的最佳兴趣值，用于后续可视化
            self.interest_history.append(self.best_paths[0]['best_interest'])

        # 返回最佳路径和兴趣值
        return self.best_paths

    # 概率性探索函数
    def find_new_path(self, path, all_paths, path_interest, time_used, ant):
        probabilities = []  # 存储转移到每个景点的概率
        spend_times = []  # 存储到达每个景点所需的时间

        # 计算到每个景点的概率
        for next_scenicSpot in range(self.num_scenicSpots):
            # 计算到下一个景点将要花费的时间
            spend_time = self.driving_times[path[-1]][next_scenicSpot] + self.scenicSpots_times[next_scenicSpot]
            spend_times.append(spend_time)
            # 如果下一个景点不在当前路径中，并且时间允许，则计算概率
            if next_scenicSpot not in path and spend_time < self.max_time - time_used:
                if self.max_time <= 10 * 8 and (*path, next_scenicSpot) in all_paths:
                    probabilities.append(0)
                    continue
                # 计算景点的信息素和兴趣值的组合影响力
                tau_eta = self.interests[next_scenicSpot] / spend_time
                probabilities.append(tau_eta)
            else:
                probabilities.append(0)  # 如果景点不可达或已经访问过，则概率为0

        sum_probabilities = sum(probabilities)
        if sum_probabilities == 0:
            return path_interest


        # 归一化概率
        probabilities = np.array(probabilities)
        probabilities /= sum_probabilities

        next_scenicSpot = np.argmax(probabilities)

        path.append(next_scenicSpot)
        path_interest += self.interests[next_scenicSpot]
        time_used += spend_times[next_scenicSpot]

        # 寻找下一个景点
        return self.find_new_path(path, all_paths, path_interest, time_used, ant)
